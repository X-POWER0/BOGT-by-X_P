#execfile('E:\\x-p\\WORK\\!WORKBENCH\\Python\\PyGame\\BdGooseMX\\main.py')
#print ("BaenDeraGOOSE-UA")

import random
import os
import sys

def we_are_frozen():
	return hasattr(sys, "frozen")
def module_path():
	if we_are_frozen():
		return os.path.dirname(unicode(sys.executible, sys.getfilesystemencoding(  )))
	return os.path.dirname(unicode(__file__, sys.getfilesystemencoding(  )))

import time

import pygame


currentWorkDir = os.getcwd()
#print(currentWorkDir)

from os.path import abspath

#for in console
#path= ('E:\\x-p\\WORK\\!WORKBENCH\\Python\\PyGame\\BdGooseMX')
#path = (os.path.dirname(os.path.abspath(__file__))) 

path = "."

from pygame.constants import QUIT, K_DOWN, K_UP, K_LEFT, K_RIGHT, K_SPACE, K_ESCAPE, K_RETURN

pygame.init()

FPS = pygame.time.Clock()

TIMER_show = pygame.font.SysFont('Verfana', 72)
HIT_show = pygame.font.SysFont('Verfana', 72)
GameOVER = -1
timer_interval = 0
timer = 20
timer_clock = pygame.time.Clock()
text_place = 'tHIT SPOT'
text_place2 = 'tHIT SPOT'
text_place3 = 'tHIT SPOT'
sysfont = pygame.font.get_default_font()
font = pygame.font.SysFont(None, 78)
HIT = 0
HEIGHT = 660
WIDTH = 800

#for console
IMAGE_PATH = path+"\\"+"Goose"
#IMAGE_PATH = "Goose"

PLAYER_IMAGES = os.listdir(IMAGE_PATH)

player_imagenext = 1
FONT = pygame.font.SysFont('Verfana', 72)
WIN = pygame.font.SysFont('Verfana', 72)
WIN1 = pygame.font.SysFont('Verfana', 72)
WIN2 = pygame.font.SysFont('Verfana', 72)
BONUS_ROUND = pygame.font.SysFont('Verfana', 72)
BONUS_RNDtxt = ' '
info =  pygame.font.SysFont('Verfana', 72)
info_text = 'Numo! GADUTI !!! - SPACE -' 
info_DONE = 0
score = 0
scoreAll = 0
image_index = 0
score_increment = 10
spacebtn = -40
RED = (255, 0, 0)
WHITE = (155, 155, 255)
COLOR_GREEN = (0, 255, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GREY = (125, 125, 125)
COLOR_BLACK = (0, 0, 0)
COLOR_BLY = (255, 255, 0)
COLOR_RED = (255, 0, 0)
COLOR_YELLOW = (0, 0, 255)
sysfont = pygame.font.get_default_font()

main_display = pygame.display.set_mode((WIDTH,HEIGHT))
#for console
bg = pygame.transform.scale(pygame.image.load(path+'//'+'image/background.png'),(WIDTH,HEIGHT))
#bg = pygame.transform.scale(pygame.image.load('image/background.png'),(WIDTH,HEIGHT))

bg_X1 = 0
bg_X2 = bg.get_width()
#bg_X2 = bg.get_height()
bg_move = 3


#count = 0

player_size = (20, 20)
#for console
player = pygame.transform.scale(pygame.image.load(path+'//'+'image/player.png').convert_alpha(),(160,80))
#player = pygame.transform.scale(pygame.image.load('image/player.png').convert_alpha(),(160,80))
#pygame.Surface(player_size)
#player.fill(COLOR_WHITE)
player_rect = player.get_rect()

#player_speed = [5, 8]

player_move_down = [0, 7] 
player_move_right = [6, 0]
player_move_up = [0, -6] 
player_move_left = [-5, 0]

#torpeda_base_rect = player.get_rect()


keys = pygame.key.get_pressed()
playing = True

enemy_speed=4

def text_objects(text, font):
    textSurface = font.render(text, True, (0,200,0))
    return textSurface, textSurface.get_rect()

def create_enemy (): 
    enemy_size = (30, 30)
#for console
    enemy = pygame.transform.scale(pygame.image.load(path+'//'+'image/enemy.png').convert_alpha(),(140,60))
#    enemy = pygame.transform.scale(pygame.image.load('image/enemy.png').convert_alpha(),(140,60))
 #pygame.Surface(enemy_size)
    enemy_width =  enemy.get_width()
    enemy_height = enemy.get_height()
    #enemy.fill(COLOR_BLY)
    enemy_rect = pygame.Rect((WIDTH + enemy.get_width()), random.randint(150 + enemy.get_height(), ((HEIGHT - enemy.get_height()) - 200)), *enemy_size)                                       
    enemy_move = [random.randint (-enemy_speed*2, -enemy_speed), 0]
    return [enemy, enemy_rect, enemy_move, enemy_width, enemy_height] 
    #enemy_move = random.choice(([0, -1],[1, 1]))
#print('123') 
def create_bonus ():
    bonus_size = (40, 40)
#for console
    bonus = pygame.transform.scale(pygame.image.load(path+'//'+'image/bonus.png').convert_alpha(),(100,120))
#    bonus = pygame.transform.scale(pygame.image.load('image/bonus.png').convert_alpha(),(100,120))
 #pygame.Surface(bonus_size)
    #bonus.fill(COLOR_RED)
    bonus_width =  bonus.get_width()
    bonus_height = bonus.get_height()
    bonus_rect = pygame.Rect(random.randint(100, (WIDTH - bonus.get_width())), ((HEIGHT - HEIGHT) - bonus.get_height()), *bonus_size)                                                  
    bonus_move = [0, random.randint (4, 8)]
    return [bonus, bonus_rect, bonus_move, bonus_height, bonus_width] 
#print('136')   
def create_torpeda():
    global score
    torpeda_size = (20, random.randint(10, 20))
    torpeda = pygame.Surface(torpeda_size)
    torpeda_rect = pygame.Rect(player_rect.left, player_rect.bottom, *torpeda_size)                                       
    torpeda.fill(COLOR_GREEN)
    torpeda_rect = pygame.Rect(player_rect.left, player_rect.bottom, *torpeda_size)                                       
    torpeda_move = [0, random.randint (6, 10)]    
    torpeda_width = torpeda.get_size()[0]
    torpeda_heigth = torpeda.get_size()[1]
    #score=score-1
    return [torpeda, torpeda_rect, torpeda_move, torpeda_heigth, torpeda_width] 


def PLAYING_GAME ():
    #print('pl')
    #print('109')
    global FPS
    global TIMER_show
    global HIT_show
    global GameOVER
    global timer_interval
    global timer
    global timer_clock
    global text_place
    global text_place2
    global text_place3
    global sysfont
    global font
    global HIT
    global HEIGHT 
    global WIDTH

    global IMAGE_PATH

    global PLAYER_IMAGES

    global player_imagenext
    global FONT
    global WIN
    global WIN1
    global WIN2
    global BONUS_ROUND
    global BONUS_RNDtxt
    global info
    global info_text
    global info_DONE
    global score
    global scoreAll
    global image_index
    global score_increment
    global spacebtn
    global RED
    global WHITE
    global COLOR_GREEN
    global COLOR_WHITE
    global COLOR_GREY
    global COLOR_BLACK
    global COLOR_BLY
    global COLOR_RED
    global COLOR_YELLOW

    global main_display
    global bg

    global bg_X1
    global bg_X2
    global bg_move

    global player_size
    global player
    global player_rect
    global player_move_down
    global player_move_right
    global player_move_up 
    global player_move_left 
    global path
    global playing
    global keys
    global ESCAPE_text
    ESCAPE_text=''
    keys = pygame.key.get_pressed()
    global ESCAPE_MENU
    ESCAPE_MENU = False
    minusScore = True
    
    ScoreSpeedUP = 0
    ScoreSpeedUPamount = 3
    SpeedUP = False
    #print('156') 
    CREATE_ENEMY = pygame.USEREVENT+1

    if HIT >= 0:
        pygame.time.set_timer(CREATE_ENEMY, 1500)

        enemies = []
    #print('162')
    CREATE_BONUS = pygame.USEREVENT+2
    pygame.time.set_timer(CREATE_BONUS, 1500)

    bonusies= []


    CREATE_TORPEDA = pygame.USEREVENT+3
    pygame.time.set_timer(CREATE_TORPEDA, 1300)
    torpediX= []


    timer_event = pygame.USEREVENT +4
    pygame.time.set_timer(timer_event, timer_interval)

    CHANGE_IMAGE = pygame.USEREVENT +5
    pygame.time.set_timer(CHANGE_IMAGE, 150)



    pygame.display.update()
    #print('247')    
    while GameOVER!=1:
        pygame.display.update()
        global keys
        keys = pygame.key.get_pressed()
        #print('249')
        for event in pygame.event.get ():
            if event.type == QUIT:
                playing = False
                sys.exit(2)
            if event.type == CREATE_ENEMY and HIT >=-1  and GameOVER != 1 and GameOVER != 2:
                enemies.append (create_enemy())
            if event.type == CREATE_BONUS and GameOVER != 1 and GameOVER != 2:
                bonusies.append (create_bonus())
            if event.type == CREATE_TORPEDA and spacebtn >= 0 and score > 0 and GameOVER != 1 and GameOVER != 2:
                torpediX.append (create_torpeda())
                spacebtn -= 100
            if event.type == CHANGE_IMAGE and GameOVER != 2:
                if image_index <= len(PLAYER_IMAGES) and player_imagenext == 1:            
                   player = pygame.image.load(os.path.join(IMAGE_PATH, PLAYER_IMAGES[image_index]))
                   image_index+= 1
                if image_index >= len(PLAYER_IMAGES) and player_imagenext == 1:
                   image_index-= 1
                   player = pygame.image.load(os.path.join(IMAGE_PATH, PLAYER_IMAGES[image_index]))                              
                   player_imagenext = 0
                if player_imagenext == 0 and image_index < len(PLAYER_IMAGES) and image_index != 0 :
                   player = pygame.image.load(os.path.join(IMAGE_PATH, PLAYER_IMAGES[image_index]))
                   image_index-= 1
                if player_imagenext == 0 and image_index < len(PLAYER_IMAGES) and image_index == 0 :
                   image_index = 0
                   player_imagenext = 1
                   player = pygame.image.load(os.path.join(IMAGE_PATH, PLAYER_IMAGES[image_index]))

        #main_display.fill(COLOR_BLACK)
        if GameOVER != 1 and GameOVER != 2:
            bg_X1 -= bg_move
            bg_X2 -= bg_move
        
        #print('281')
        #if bg_X1 < -bg.get_height():
            #bg_X1 = bg.get_height()

        #if bg_X2 < -bg.get_height():
            #bg_X2 = bg.get_height()

        if bg_X1 < -bg.get_width() and GameOVER != 1 and GameOVER != 2:
            bg_X1 = bg.get_width()
        #print('290')
        if bg_X2 < -bg.get_width() and GameOVER != 1 and GameOVER != 2:
            bg_X2 = bg.get_width()
        #print('293')
        #main_display.blit(bg, (0, bg_X1))
        #main_display.blit(bg, (0, bg_X2))

        if GameOVER != 1 and GameOVER != 2:
            main_display.blit(bg, (bg_X1, 0))
            main_display.blit(bg, (bg_X2, 0))
            
                
        if keys[K_DOWN] and player_rect.bottom < HEIGHT and GameOVER != 1 and GameOVER != 2:
            player_rect = player_rect.move(player_move_down)

        if keys[K_UP] and player_rect.top > (HEIGHT - HEIGHT) and GameOVER != 1 and GameOVER != 2:
            player_rect = player_rect.move(player_move_up)

        if keys[K_RIGHT] and player_rect.right < WIDTH and GameOVER != 1 and GameOVER != 2:
            player_rect =  player_rect.move(player_move_right)

        if keys[K_LEFT] and player_rect.left > (WIDTH - WIDTH) and GameOVER != 1 and GameOVER != 2:
            player_rect =  player_rect.move(player_move_left)

        if keys[K_SPACE] and score > 0  and GameOVER != 1 and GameOVER != 2:
            spacebtn = 0
            spacebtn += 30
            create_torpeda()

        if len(torpediX)<=0 and minusScore==True:
            minusScore = False        
        if len(torpediX)>=1 and minusScore==True:
            global score
            score =-1
            minusScore = False


        for torpeda in torpediX:
            if GameOVER != 1 and GameOVER != 2:
                global score
                torpeda[1] = torpeda[1].move(torpeda[2])
                main_display.blit(torpeda[0], torpeda[1])
                #score=-1


        for enemy in enemies:
            if GameOVER != 1 and GameOVER != 2:
                enemy[1] = enemy[1].move(enemy[2])
                main_display.blit(enemy[0], enemy[1])

    #        if enemy[1].left >= ((WIDTH - WIDTH) + enemy[1].left):
    #           main_display.blit(enemy[0], enemy[1])


            for torpeda in torpediX:
                if torpeda[1].colliderect(enemy[1]) and HIT >= 0 and GameOVER != 1 and GameOVER != 2:
                   global HIT
                   HIT+= 1
                   enemies.pop(enemies.index (enemy))
                   torpediX.pop(torpediX.index (torpeda))
                   global minusScore
                   minusScore = True
                   if HIT>=ScoreSpeedUP:
                       global enemy_speed
                       enemy_speed=enemy_speed+round(HIT*0.4)
                   if HIT>ScoreSpeedUP+1:
                       ScoreSpeedUP=HIT+ScoreSpeedUPamount
                       global enemy_speed
                       enemy_speed=4
            
            if player_rect.colliderect(enemy[1]) and GameOVER != 1 and GameOVER != 2:
               GameOVER = 1 
              # playing = False
               
        for bonus in bonusies:
            if GameOVER != 1 and GameOVER != 2:
                bonus[1] = bonus[1].move(bonus[2])
                main_display.blit(bonus[0], bonus[1])
            if player_rect.colliderect(bonus[1]) and GameOVER != 1 and GameOVER != 2:
                 global score
                 score+= 1
                 global scoreAll
                 scoreAll+= 1
                 bonusies.pop(bonusies.index (bonus))
        if  info_DONE != 1 and spacebtn < 3 :
            info_text = 'Numo! GADUTI !!! - SPACE -' 
            main_display.blit(info.render(str(info_text), True, COLOR_YELLOW), (WIDTH/2-260, (HEIGHT - 90)))
            if spacebtn > 4 :
                info_DONE = 1


        if  info_DONE == 1 and spacebtn > 4 :
            info_text = '' 
            main_display.blit(info.render(str(info_text), True, COLOR_YELLOW), (WIDTH/2-60, (HEIGHT - 70)))

        #print('371')
        for enemy in enemies:
            if enemy[1].left <= (WIDTH - WIDTH) - enemy[3]  or enemy[1].right >= (WIDTH + (2 * enemy[3])) or enemy[1].top <= ((HEIGHT - HEIGHT) + enemy[4])  or enemy[1].top >= (HEIGHT - enemy[4]) :
                enemies.pop(enemies.index(enemy))

        for bonus in bonusies:
            if bonus[1].left < ((WIDTH - WIDTH) + (bonus[3] * 3)) or bonus[1].right >= (WIDTH - bonus[3]) or bonus[1].top >= (HEIGHT - bonus[4]) or bonus[1].top <= ((HEIGHT - HEIGHT) - (bonus[4] * 2)):
                bonusies.pop(bonusies.index(bonus))

        #print('381') 
        for torpeda in torpediX:
            if torpeda[1].left < ((WIDTH - WIDTH) + (torpeda[3] * 3)) or torpeda[1].right >= (WIDTH - torpeda[3]) or torpeda[1].top >= (HEIGHT - torpeda[4]) or torpeda[1].top <= ((HEIGHT - HEIGHT) - (torpeda[4] * 2)):
                torpediX.pop(torpediX.index(torpeda))
                global minusScore
                minusScore = True

         
        main_display.blit(FONT.render(str(score), True, COLOR_GREEN), (WIDTH-50, 20))
        main_display.blit(FONT.render(str(scoreAll), True, COLOR_GREY), (WIDTH-130, 20))
        main_display.blit(HIT_show.render(str(HIT), True, COLOR_RED), ((WIDTH-WIDTH) + 50, 20))    
        #main_display.blit(TIMER_show.render(str(timer + timer_interval), True, COLOR_RED), ((WIDTH-WIDTH) + 50, 220))    
        main_display.blit(player, player_rect)
        if SpeedUP==True:
            ScoreSpeedUP = HIT + ScoreSpeedUPamount
            SpeedUP==False
        
        
        
        global ESCAPE_MENU
        if keys[K_ESCAPE] and ESCAPE_MENU==False:
            global ESCAPE_MENU
            ESCAPE_MENU = True
            global GameOVER
            GameOVER=2
        if ESCAPE_MENU==True:
            global ESCAPE_text
            ESCAPE_text = 'EXIT - Enter, PLAY - Space' 
            main_display.blit(info.render(str(ESCAPE_text), True, COLOR_RED), (WIDTH/2-260, (HEIGHT - 140)))
            keys = pygame.key.get_pressed()
            if keys[K_RETURN] and ESCAPE_MENU==True:
                pygame.display.quit()
                pygame.quit()
                sys.exit(2)
            if keys[K_SPACE] and ESCAPE_MENU==True:
                main_display.blit(info.render(str(ESCAPE_text), True, COLOR_RED), (WIDTH/2-260, (HEIGHT - 140)))
                pygame.display.update()
                global GameOVER
                GameOVER=0
                global ESCAPE_text
                ESCAPE_text = '' 
                pygame.display.update()
                global ESCAPE_MENU
                ESCAPE_MENU=False
                
        
           
while playing:
    FPS.tick (10)
    keys = pygame.key.get_pressed()
    for event in pygame.event.get ():
        if event.type == QUIT:
            playing = False
            sys.exit(2)
    if GameOVER == -1:  
        main_display.fill((0, 0, 0))
        largeText = pygame.font.SysFont("comicsansms",20)
        TextSurf, TextRect = text_objects("Space or Enter for START", largeText)
        TextRect.center = ((WIDTH/2),(HEIGHT/2))
        main_display.blit(TextSurf, TextRect)
        pygame.display.update() 
        #print('328') 
        if keys[K_ESCAPE]:
            #print("ESC was pressed. quitting...")
            #self._print("ESC was pressed. quitting...")
            pygame.display.quit()
            pygame.quit()
            sys.exit(2)
            #self.quit()
        if keys[K_SPACE] or keys[K_RETURN]:
            #print('335') 
            global GameOVER
            GameOVER = 0
            global Info_DONE
            Info_DONE = 0    
            global HIT    
            HIT = 0
            global score
            score = 0
            global scoreAll
            scoreAll = 0
            PLAYING_GAME()
            
    if GameOVER == 1:  
        main_display.fill((0, 0, 0))
        largeText = pygame.font.SysFont("comicsansms",20)
        TextSurf, TextRect = text_objects("Game Over.    Press Space to restart.", largeText)
        TextRect.center = ((WIDTH/2),(HEIGHT/2))
        main_display.blit(TextSurf, TextRect)
        
        pygame.display.update() 
        if keys[K_ESCAPE]:
            #self._print("ESC was pressed. quitting...")
            pygame.display.quit()
            pygame.quit()
            sys.exit(2)
            #self.quit()
        if keys[K_SPACE]:
            global GameOVER
            GameOVER = 0
            global Info_DONE
            Info_DONE = 0
            global enemy_speed
            enemy_speed = 4
            global ScoreSpeedUP
            ScoreSpeedUP = 4
            global HIT
            HIT = 0
            global score
            score = 0
            global scoreAll
            scoreAll = 0
            PLAYING_GAME()




        #main_display.blit(enemy, enemy_rect)
        #main_display.blit(img, text_rect)

        #print(len(enemies))

        #player_rect = player_rect.move(player_speed)
    main_display.blit(FONT.render(str(score), True, COLOR_GREEN), (WIDTH-50, 20))
    main_display.blit(FONT.render(str(scoreAll), True, COLOR_GREY), (WIDTH-130, 20))
    main_display.blit(HIT_show.render(str(HIT), True, COLOR_RED), ((WIDTH-WIDTH) + 50, 20))    
    #main_display.blit(TIMER_show.render(str(timer + timer_interval), True, COLOR_RED), ((WIDTH-WIDTH) + 50, 220))    
    main_display.blit(player, player_rect)
    pygame.display.flip()

while True:
    keys = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            playing=false
            sys.exit(2)
	if keys[K_ESCAPE]:
		#print("ESC was pressed. quitting...")
		#self._print("ESC was pressed. quitting...")
		pygame.display.quit()
		pygame.quit()
		sys.exit()
		#self.quit()
	if keys[K_SPACE] or keys[K_RETURN]:
		#print('335') 
                global GameOVER
		GameOVER = 0
		global Info_DONE
		Info_DONE = 0        
		global HIT
		HIT = 0
		global score
		score = 0
		global scoreAll
		scoreAll = 0
		PLAYING_GAME()